# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['src']

package_data = \
{'': ['*']}

install_requires = \
['diff-match-patch>=20200713,<20200714', 'dominate>=2.6.0,<3.0.0']

setup_kwargs = {
    'name': 'src',
    'version': '0.1.0',
    'description': "Create diff html like difflib using google's diff_match_patch",
    'long_description': None,
    'author': 'mochisue',
    'author_email': 'motoki32925@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
